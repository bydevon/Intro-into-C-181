/*************************************************************************
Cuyamaca College CS-181
File name: Lab2Exercise2.cpp
Description: Lab 02, Exercise 2, Write a program that stores the integers 50 and 100 in variables, stores the product of these two in a variable 
named total, and displays the total. 
Developer: Devon Ellison
*************************************************************************/
#include <iostream>
using namespace std;


// My Solution

int main()
{
    
        int fifty = 50;
        int hundred = 100;

        double total = fifty * hundred;

        cout << "The Total is " << total << endl;
        return 0;
}