/*************************************************************************
Cuyamaca College CS-181
File name: Lab2Exercise1.cpp
Description: Lab 02, Exercise 1, Fix the mixed up C ++ code from page 30
Developer: Devon Ellison
*************************************************************************/


/* Problem
int main()
}
// A crazy mixed up program
return 0;
#include <iostream>
cout << "In 1492 Columbus sailed the ocean blue.";
{
using namespace std;
*/

// My Solution

#include <iostream>
using namespace std;

int main()
{
    cout << "In 1492 Columbus sailed the ocean blue.";
    return 0;
}

